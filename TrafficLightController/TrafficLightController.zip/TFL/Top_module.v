module Top_module(
    input  wire       clk,
    input  wire       reset,
    input  wire [1:0] state,          // Cổng nạp state ban đầu
    output wire [1:0] current_state,  // Xuất state hiện tại ra ngoài để quan sát
    output wire [3:0] data_out,       // Tín hiệu đèn từ Decoder
    output wire [3:0] data_out2       // Giá trị đếm lùi từ Counter
);
    wire z;
    wire Din;
    wire [1:0] next_state;

    // Khi z = 1 (chuẩn bị chuyển trạng thái), nạp trước mốc thời gian của next_state cho Counter
    wire [1:0] state_for_counter = (z == 1'b1) ? next_state : current_state;

    Control u_control (
        .clk(clk),
        .reset(reset),
        .z(z),
        .state(state),
        .current_state(current_state),
        .next_state(next_state)
    );

    SetCounter u_set_counter (
        .data_in(state_for_counter),
        .data_out(Din)
    );

    Counter u_counter (
        .clk(clk),
        .rst(reset),
        .mode_3_15(Din),
        .count(data_out2),
        .z(z)
    );

    Decoder u_decoder (
        .data_in(current_state),
        .signal(data_out)
    );

endmodule