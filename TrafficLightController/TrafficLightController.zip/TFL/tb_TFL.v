`timescale 1ns/100ps

module tb_TFL();
    // Tín hiệu kích thích (Inputs to DUT)
    reg        clk;
    reg        reset;
    reg  [1:0] state;         

    // Tín hiệu quan sát (Outputs from DUT)
    wire [1:0] current_state; // State thực tế đang chạy
    wire [3:0] data_out;      // Tín hiệu đèn
    wire [3:0] data_out2;     // Bộ đếm đếm lùi

    // Biến đếm lỗi
    integer error_count;

    // Kết nối với Top Module
    Top_module dut (
        .clk(clk),
        .reset(reset),
        .state(state),
        .current_state(current_state),
        .data_out(data_out),
        .data_out2(data_out2)
    );

    // Tạo xung Clock: chu kỳ 10ns (f = 100MHz)
    always #5 clk = ~clk;

    // Task kiểm tra tín hiệu đèn và trạng thái
    task check;
        input [1:0] exp_state;
        input [3:0] exp_light;
        begin
            if (current_state !== exp_state || data_out !== exp_light) begin
                $display("[FAIL] Thoi diem %0t ns | State: %b (mong doi: %b) | Den: %b (mong doi: %b)",
                         $time, current_state, exp_state, data_out, exp_light);
                error_count = error_count + 1;
            end else begin
                $display("[PASS] Thoi diem %0t ns | State: %b | Den: %b | Count: %0d",
                         $time, current_state, data_out, data_out2);
            end
        end
    endtask

    // Kịch bản mô phỏng
    initial begin
        $dumpfile("tb_TFL.vcd");
        $dumpvars(0, tb_TFL);

        // Khởi tạo
        clk = 0;
        reset = 1;
        state = 2'b00; // <--- KHỞI TẠO STATE BAN ĐẦU TẠI ĐÂY (S0)
        error_count = 0;
        $display("BAT DAU");
        // Giữ Reset trong 20ns
        #20;
        reset = 0;
        $display("--> Da nha Reset tai %0t ns. State khoi tao duoc nap: %b", $time, state);

        // Chờ 1ns để dữ liệu ổn định và kiểm tra S0
        #1;
        check(2'b00, 4'b0001);

        // Chờ đếm xong S0 (khi z = 1)
        @(posedge dut.u_control.z);
        $display("--> Het thoi gian S0 tai %0t ns (Count = %0d), chuan bi sang S1", $time, data_out2);

        // Chờ cạnh clock để chuyển sang S1
        @(posedge clk);
        #1;
        check(2'b01, 4'b0010); // S1: 3s, đèn 4'b0010

        // Chờ đếm xong S1
        @(posedge dut.u_control.z);
        $display("--> Het thoi gian S1 tai %0t ns (Count = %0d), chuan bi sang S2", $time, data_out2);

        // Chờ cạnh clock để chuyển sang S2
        @(posedge clk);
        #1;
        check(2'b10, 4'b0100); // S2: 15s, đèn 4'b0100

        // Chờ đếm xong S2
        @(posedge dut.u_control.z);
        $display("--> Het thoi gian S2 tai %0t ns (Count = %0d), chuan bi sang S3", $time, data_out2);

        // Chờ cạnh clock để chuyển sang S3
        @(posedge clk);
        #1;
        check(2'b11, 4'b1000); // S3: 3s, đèn 4'b1000

        // Chờ đếm xong S3 quay về S0
        @(posedge dut.u_control.z);
        $display("--> Het thoi gian S3 tai %0t ns (Count = %0d), chuan bi quay lai S0", $time, data_out2);

        @(posedge clk);
        #1;
        check(2'b00, 4'b0001); // Quay lại S0 thành công

        #100;
        if (error_count == 0)
            $display(">>> KET QUA: TAT CA TESTCASES DEU PASS HOAN HAO! <<<");
        else
            $display(">>> KET QUA: CO %0d LOI XAY RA! <<<", error_count);
        $finish;
    end

endmodule
