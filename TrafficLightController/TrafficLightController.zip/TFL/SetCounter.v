module SetCounter (
    input  wire [1:0] data_in,
    output reg        data_out
);
    always @(*) begin
        case (data_in)
            2'b00: data_out = 1'b1; // S0: 15s (đèn Xanh 1)
            2'b01: data_out = 1'b0; // S1: 3s  (đèn Vàng 1)
            2'b10: data_out = 1'b1; // S2: 15s (đèn Xanh 2)
            2'b11: data_out = 1'b0; // S3: 3s  (đèn Vàng 2)
            default: data_out = 1'b1;
        endcase
    end
endmodule