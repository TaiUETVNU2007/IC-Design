module Control (
    input  wire       clk,
    input  wire       reset,
    input  wire       z,
    input  wire [1:0] state,           // Khởi tạo state ban đầu
    output reg  [1:0] current_state,
    output reg  [1:0] next_state
);
    // Mã hóa 4 trạng thái
    localparam [1:0] S0 = 2'b00,
                     S1 = 2'b01,
                     S2 = 2'b10,
                     S3 = 2'b11;

    // Khởi tạo giá trị ban đầu trong mô phỏng
    initial begin
        current_state = 2'b00;
    end

    // Khởi tạo state ban đầu khi reset hoặc chuyển trạng thái khi hết giờ (z = 1)
    always @(posedge clk or posedge reset) begin
        if (reset == 1'b1)
            current_state <= state;    // Nạp trạng thái ban đầu từ ngõ vào 'state'
        else if (z == 1'b1)
            current_state <= next_state;
    end

    // Logic xác định trạng thái tiếp theo
    always @(*) begin
        case (current_state)
            S0: next_state = S1;
            S1: next_state = S2;
            S2: next_state = S3;
            S3: next_state = S0;
            default: next_state = S0;
        endcase    
    end
endmodule
