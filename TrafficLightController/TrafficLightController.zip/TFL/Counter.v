module Counter (
    input  wire       clk,        // Xung clock
    input  wire       rst,        // Tín hiệu reset
    input  wire       mode_3_15,  // Tín hiệu chọn thời gian: 1 -> 15s, 0 -> 3s
    output reg  [3:0] count,      // Giá trị bộ đếm (4-bit đủ đếm tới 15)
    output wire       z           // Tín hiệu z báo khi đếm về 1
);
    // Logic của z: tích cực mức 1 khi count chạm 1
    assign z = (count == 4'd1) ? 1'b1 : 1'b0;

    // Logic MUX chọn giá trị nạp lại (15 hoặc 3)
    wire [3:0] reload_value;
    assign reload_value = mode_3_15 ? 4'd15 : 4'd3;

    // Khối đếm đồng bộ tích hợp MUX
    always @(posedge clk or posedge rst) begin
        if (rst == 1'b1) begin
            count <= 4'd0;
        end else begin
            // Kiểm tra tín hiệu z (điều khiển MUX nạp lại)
            if (z) begin
                count <= reload_value;
            end else begin
                if (count > 4'd0) begin
                    count <= count - 1'b1;
                end else begin
                    count <= reload_value;
                end
            end
        end
    end
endmodule